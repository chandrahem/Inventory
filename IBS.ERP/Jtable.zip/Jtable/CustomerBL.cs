﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IBS.ERP.DataAccess;
using IBS.ERP.Models;

namespace IBS.ERP.BL
{
   public class CustomerBL
    {

       public List<CustomerMaster> GetCandidateDocuments(Paging objPaging, out Int32 TotalRows)
       {

           return CustomerDAL.GetCandidateDocuments(objPaging, out  TotalRows);
       }
    }
}
