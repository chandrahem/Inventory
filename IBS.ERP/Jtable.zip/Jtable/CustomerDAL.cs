﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using IBS.ERP.Models;

namespace IBS.ERP.DataAccess
{
   public class CustomerDAL
    {
       private const string SP_CustomerInformation = "[SP_CustomerInformation]";
      public static List<CustomerMaster> GetCandidateDocuments(Paging objPaging, out Int32 TotalRows)
       {
           List<CustomerMaster> ListReq = null;
           TotalRows = 0;
           try
           {
               using (SqlCommand cmd = new SqlCommand(SP_CustomerInformation))
               {
                   using (SqlConnection con = new SqlConnection(@"Data Source=SONY-PC\SQLEXPRESS; Initial Catalog=LearningNew;User ID=EA_user;Password=123;"))
                   {
                       cmd.CommandType = CommandType.StoredProcedure;

                       if (con.State == ConnectionState.Closed)
                           con.Open();

                       cmd.Connection = con;


                       cmd.Parameters.AddWithValue("@StartRowIndex", 1);
                       cmd.Parameters.AddWithValue("@MaxRows", 5);
                       cmd.Parameters.AddWithValue("@OrderBy", objPaging.OrderBy);
                       cmd.Parameters.AddWithValue("@Order", objPaging.Order);

                       using (SqlDataReader sdr = cmd.ExecuteReader())
                       {
                           ListReq = cCommon.GetList<CustomerMaster>(sdr);
                           if (sdr.NextResult())
                           {
                               while (sdr.Read())
                               {
                                   TotalRows = Int32.Parse(sdr["TotalRows"].ToString());
                               }
                           }
                           sdr.Close();
                           sdr.Dispose();
                       }
                   }
                   cmd.Dispose();
               }
           }
           catch (SqlException ex)
           {

           }
           finally
           {
           }
           return ListReq;
       }
    }
}
