﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using IBS.ERP.BL;
using IBS.ERP.Models;

namespace IBS.ERP.Controllers
{
    public class CustomerController : Controller
    {
        // GET: Customer
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public JsonResult GetStudentMarks(int jtStartIndex, int jtPageSize)
        {
            List<CustomerMaster> documentList = null;
            int totalRows = 0;
      
           
                jtStartIndex = jtStartIndex == 0 ? 0 : (jtStartIndex / jtPageSize + 1);
               
                Paging objpaging = new Paging
                {
                    MaxRows = jtPageSize,
                    Order = "DESC",
                    OrderBy = "CustomerID",//"CP.UpdatedDate",
                    StartRowIndex = jtStartIndex
                };
               CustomerBL obj=new CustomerBL();

             var docList=  obj.GetCandidateDocuments(objpaging,out totalRows);

               documentList=docList.ToList<CustomerMaster>();
               // var docList =  cMasterServices.Current().GetCandidateDocuments( objpaging,out totalRows);
           // ApplicationDbContext db = new ApplicationDbContext();
            try
            {
               
                return Json(new { Result = "OK", Records = documentList ,TotalRecordCount = totalRows}, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR", Message = ex.Message });
            }
        }  
        }

}